
# Robinhood
rob_username=''
rob_password=''
rob_backup_code =''
rob_pyotp = '' #this is device id

#TD Ameritrade
tda_api_key = ''
tda_token_path = 'token' #this will create a file name token
tda_redirect_uri = 'http://localhost'
tda_account_id = ''
